
  # Kardex Temporales

  This is a code bundle for Kardex Temporales. The original project is available at https://www.figma.com/design/LAsqwKJTL0AoS56nGFufXg/Kardex-Temporales.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  