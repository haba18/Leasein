import { Pencil, AlertTriangle, PackageCheck, Search, Filter, Loader2, CheckCircle2, Clock, Eye } from 'lucide-react';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Checkbox } from './ui/checkbox';
import { Input } from './ui/input';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from './ui/table';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "./ui/select";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "./ui/dialog";
import {
  Pagination,
  PaginationContent,
  PaginationItem,
  PaginationLink,
  PaginationNext,
  PaginationPrevious,
  PaginationEllipsis,
} from "./ui/pagination";
import { useState } from 'react';

export interface Equipment {
  id: number;
  codigo_equipo: string;
  marca_modelo: string;
  cliente: string;
  motivo: string;
  recibido_por: string;
  area: string;
  prioridad_alta: boolean;
  fecha_ingreso: string | null;
  fecha_salida: string | null;
  entregado_a: string | null;
  especialista: string | null;
  observaciones_ingreso: string | null;
  observaciones_salida: string | null;
  dias_en_custodia: number;
  estado_proceso?: string;
}

interface EquipmentTableProps {
  equipos: Equipment[];
  onEdit: (equipo: Equipment) => void;
  onMarkExit: (equipo: Equipment) => void;
  onUpdateStatus: (equipo: Equipment, newStatus: string) => void;
  selectedIds: number[];
  onSelectionChange: (ids: number[]) => void;
  activeFilter?: 'preparacion' | 'urgentes' | 'dias' | null;
  readOnly?: boolean;
}

// Calcular estado visual simplificado según solicitud del usuario
const calcularEstadoAlerta = (fecha_salida: string | null, prioridad_alta: boolean): string => {
  if (fecha_salida) return 'LISTO';
  if (prioridad_alta) return 'URGENTE';
  return 'REGISTRADO';
};

const getEstadoBadge = (estado: string) => {
  switch (estado) {
    case 'LISTO':
      return <Badge variant="outline" className="bg-emerald-50 text-emerald-700 border-emerald-200 shadow-sm">Listo</Badge>;
    case 'URGENTE':
      return (
        <Badge variant="destructive" className="flex items-center gap-1 shadow-sm">
          <AlertTriangle className="h-3 w-3" />
          URGENTE
        </Badge>
      );
    case 'REGISTRADO':
      return <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-200 shadow-sm">Registrado</Badge>;
    default:
      return <Badge variant="outline">{estado}</Badge>;
  }
};

const getRowClassName = (estado: string) => {
  if (estado === 'URGENTE') {
    return 'bg-red-50/50 dark:bg-red-950/20 hover:bg-red-50 dark:hover:bg-red-950/30';
  }
  if (estado === 'LISTO') {
    return 'bg-emerald-50/30 dark:bg-emerald-950/10 hover:bg-emerald-50 dark:hover:bg-emerald-950/20';
  }
  return 'hover:bg-slate-50 dark:hover:bg-slate-900/50';
};

const formatFecha = (fecha: string | null, soloFecha = false) => {
  if (!fecha) return '-';
  try {
    const date = new Date(fecha);
    if (isNaN(date.getTime())) return '-';
    
    // Siempre mostrar solo la fecha (sin hora)
    return new Intl.DateTimeFormat('es-PE', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
      timeZone: 'America/Lima'
    }).format(date);
  } catch {
    return '-';
  }
};

// Función para calcular días en custodia dinámicamente
const calcularDiasCustodia = (fechaIngreso: string | null, fechaSalida: string | null, diasBackend: number): number => {
  if (!fechaIngreso) return 0;
  
  try {
    // PARSEAR FECHA DE INGRESO (asumiendo formato ISO del backend)
    // Extraer solo la parte de la fecha YYYY-MM-DD
    const fechaIngresoStr = fechaIngreso.split('T')[0]; // "2026-02-13"
    const [yearIngreso, monthIngreso, dayIngreso] = fechaIngresoStr.split('-').map(Number);
    
    // Si el equipo ya salió, calcular días entre ingreso y salida
    if (fechaSalida) {
      const fechaSalidaStr = fechaSalida.split('T')[0];
      const [yearSalida, monthSalida, daySalida] = fechaSalidaStr.split('-').map(Number);
      
      // Crear fechas usando UTC para evitar problemas de zona horaria
      const ingresoDate = Date.UTC(yearIngreso, monthIngreso - 1, dayIngreso);
      const salidaDate = Date.UTC(yearSalida, monthSalida - 1, daySalida);
      
      const diffMs = salidaDate - ingresoDate;
      const dias = Math.floor(diffMs / (1000 * 60 * 60 * 24));
      
      console.log(`📅 EQUIPO CON SALIDA | Ingreso: ${fechaIngresoStr} | Salida: ${fechaSalidaStr} | Días: ${dias}`);
      
      return Math.max(0, dias);
    }

    // Si sigue en custodia, calcular días hasta HOY (en Perú UTC-5)
    const ahora = new Date();
    const yearHoy = ahora.getFullYear();
    const monthHoy = ahora.getMonth(); // Ya está en 0-11
    const dayHoy = ahora.getDate();
    
    // Crear fechas usando UTC
    const ingresoDate = Date.UTC(yearIngreso, monthIngreso - 1, dayIngreso);
    const hoyDate = Date.UTC(yearHoy, monthHoy, dayHoy);
    
    const diffMs = hoyDate - ingresoDate;
    const dias = Math.floor(diffMs / (1000 * 60 * 60 * 24));
    
    console.log(`📦 EN CUSTODIA | Ingreso: ${fechaIngresoStr} | Hoy: ${yearHoy}-${String(monthHoy + 1).padStart(2, '0')}-${String(dayHoy).padStart(2, '0')} | Días: ${dias}`);
    
    return Math.max(0, dias);
    
  } catch (error) {
    console.error('❌ ERROR calculando días en custodia:', error, { fechaIngreso, fechaSalida });
    return 0;
  }
};

export function EquipmentTable({ 
  equipos, 
  onEdit, 
  onMarkExit, 
  onUpdateStatus,
  selectedIds, 
  onSelectionChange, 
  activeFilter,
  readOnly = false 
}: EquipmentTableProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [motivoFilter, setMotivoFilter] = useState<string>('todos');
  const [currentPage, setCurrentPage] = useState(1);
  const [observacionesDialog, setObservacionesDialog] = useState<{ open: boolean; content: string; }>({ open: false, content: '' });
  
  const itemsPerPage = 20;

  // Obtener motivos únicos para el filtro
  const uniqueMotivos = Array.from(new Set(equipos.map(e => e.motivo))).filter(Boolean).sort();

  // Filtrar equipos por búsqueda y motivo
  const filteredEquipos = equipos.filter(equipo => {
    // Búsqueda múltiple: separar por espacios o comas, normalizar y comparar
    const searchTerms = searchQuery
      .toUpperCase()
      .replace(/'/g, '-') // Reemplazar apóstrofe por guion
      .split(/[\s,]+/) // Separar por espacios o comas
      .filter(term => term.length > 0); // Eliminar términos vacíos
    
    // Si no hay términos de búsqueda, mostrar todos
    if (searchTerms.length === 0) {
      const matchesMotivo = motivoFilter === 'todos' || equipo.motivo === motivoFilter;
      return matchesMotivo;
    }
    
    // Verificar si el código del equipo coincide con ALGUNO de los términos
    const codigoNormalizado = equipo.codigo_equipo.toUpperCase().replace(/'/g, '-');
    const matchesSearch = searchTerms.some(term => codigoNormalizado.includes(term));
    const matchesMotivo = motivoFilter === 'todos' || equipo.motivo === motivoFilter;
    
    return matchesSearch && matchesMotivo;
  });

  // Calcular paginación
  const totalPages = Math.ceil(filteredEquipos.length / itemsPerPage);
  const startIndex = (currentPage - 1) * itemsPerPage;
  const endIndex = startIndex + itemsPerPage;
  const paginatedEquipos = filteredEquipos.slice(startIndex, endIndex);

  // Resetear a página 1 cuando cambian los filtros
  const handleSearchChange = (value: string) => {
    setSearchQuery(value);
    setCurrentPage(1);
  };

  const handleMotivoChange = (value: string) => {
    setMotivoFilter(value);
    setCurrentPage(1);
  };

  const handleToggleAll = () => {
    // Solo seleccionar equipos que NO tengan salida marcada de la página actual
    const seleccionables = paginatedEquipos.filter(eq => !eq.fecha_salida);
    
    if (selectedIds.length === seleccionables.length && seleccionables.length > 0) {
      onSelectionChange([]);
    } else {
      onSelectionChange(seleccionables.map(eq => eq.id));
    }
  };

  const handleToggleOne = (id: number) => {
    const equipo = equipos.find(e => e.id === id);
    if (equipo?.fecha_salida && !selectedIds.includes(id)) {
      return;
    }

    if (selectedIds.includes(id)) {
      onSelectionChange(selectedIds.filter(selectedId => selectedId !== id));
    } else {
      onSelectionChange([...selectedIds, id]);
    }
  };

  const allSelected = paginatedEquipos.length > 0 && selectedIds.length === paginatedEquipos.length;

  // Generar números de página
  const getPageNumbers = () => {
    const pages = [];
    const maxVisible = 5;
    
    if (totalPages <= maxVisible) {
      for (let i = 1; i <= totalPages; i++) {
        pages.push(i);
      }
    } else {
      if (currentPage <= 3) {
        for (let i = 1; i <= 4; i++) pages.push(i);
        pages.push('ellipsis');
        pages.push(totalPages);
      } else if (currentPage >= totalPages - 2) {
        pages.push(1);
        pages.push('ellipsis');
        for (let i = totalPages - 3; i <= totalPages; i++) pages.push(i);
      } else {
        pages.push(1);
        pages.push('ellipsis');
        pages.push(currentPage - 1);
        pages.push(currentPage);
        pages.push(currentPage + 1);
        pages.push('ellipsis');
        pages.push(totalPages);
      }
    }
    
    return pages;
  };

  return (
    <div className="space-y-4">
      {/* Barra de búsqueda y filtros */}
      <div className="flex flex-col sm:flex-row items-center gap-3 bg-white dark:bg-gray-950 border rounded-lg p-3 lg:p-4 shadow-sm">
        <div className="flex items-center gap-2 flex-1 w-full min-w-0">
          <Search className="h-4 w-4 lg:h-5 lg:w-5 text-muted-foreground flex-shrink-0" />
          <Input
            placeholder="Buscar por código..."
            value={searchQuery}
            onChange={(e) => handleSearchChange(e.target.value)}
            className="flex-1 min-w-0 border-0 focus-visible:ring-0 focus-visible:ring-offset-0 text-sm lg:text-base font-mono"
          />
          {searchQuery && (
            <Button
              variant="ghost"
              size="sm"
              onClick={() => handleSearchChange('')}
              className="text-xs flex-shrink-0"
            >
              Limpiar
            </Button>
          )}
        </div>
        
        {/* Filtro por motivo */}
        <div className="w-full sm:w-[200px] flex-shrink-0">
          <Select value={motivoFilter} onValueChange={handleMotivoChange}>
            <SelectTrigger className="w-full border-0 sm:border bg-transparent sm:bg-background">
              <div className="flex items-center gap-2 text-muted-foreground">
                <Filter className="h-4 w-4" />
                <SelectValue placeholder="Filtrar por motivo" />
              </div>
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="todos">Todos los motivos</SelectItem>
              {uniqueMotivos.map(motivo => (
                <SelectItem key={motivo} value={motivo}>{motivo}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        
        {/* Información de paginación */}
        <div className="flex items-center gap-3 text-xs text-muted-foreground whitespace-nowrap flex-shrink-0">
          {/* Contador de seleccionados */}
          {!readOnly && selectedIds.length > 0 && (
            <div className="bg-blue-100 text-blue-700 px-2.5 py-1 rounded-md font-semibold border border-blue-200">
              {selectedIds.length} seleccionado{selectedIds.length !== 1 ? 's' : ''}
            </div>
          )}
          
          {/* Información de paginación */}
          {filteredEquipos.length > 0 ? (
            <>
              Mostrando {startIndex + 1}-{Math.min(endIndex, filteredEquipos.length)} de {filteredEquipos.length}
            </>
          ) : (
            'Sin resultados'
          )}
        </div>
      </div>

      {/* Vista de escritorio - Tabla */}
      <div className="hidden lg:block border rounded-lg overflow-hidden shadow-sm bg-white dark:bg-gray-950">
        <div className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow className="bg-gray-50/50 dark:bg-gray-900/50">
                {!readOnly && (
                  <TableHead className="w-12">
                    <Checkbox
                      checked={allSelected}
                      onCheckedChange={handleToggleAll}
                    />
                  </TableHead>
                )}
                <TableHead>Código</TableHead>
                <TableHead>Cliente</TableHead>
                <TableHead className="text-center">Observaciones</TableHead>
                <TableHead>Motivo</TableHead>
                <TableHead>Especialista</TableHead>
                <TableHead className="text-center font-bold text-gray-700 dark:text-gray-300">Días en Custodia</TableHead>
                <TableHead className="text-center">Estado</TableHead>
                <TableHead>Fecha Ingreso</TableHead>
                <TableHead>Fecha Salida</TableHead>
                {!readOnly && <TableHead className="text-right">Acciones</TableHead>}
              </TableRow>
            </TableHeader>
            <TableBody>
              {paginatedEquipos.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={readOnly ? 9 : 11} className="text-center py-12 text-muted-foreground">
                    <div className="flex flex-col items-center gap-2">
                      <div className="p-3 bg-gray-100 dark:bg-gray-800 rounded-full">
                        <PackageCheck className="h-6 w-6 text-gray-400" />
                      </div>
                      <p>
                        {searchQuery || motivoFilter !== 'todos'
                          ? 'No se encontraron equipos con los filtros seleccionados'
                          : 'No hay equipos registrados.'}
                      </p>
                    </div>
                  </TableCell>
                </TableRow>
              ) : (
                paginatedEquipos.map((equipo) => {
                  const diasCustodia = calcularDiasCustodia(equipo.fecha_ingreso, equipo.fecha_salida, equipo.dias_en_custodia);
                  const estadoAlerta = calcularEstadoAlerta(equipo.fecha_salida, equipo.prioridad_alta);
                  const estadoProceso = equipo.fecha_salida ? 'TERMINADO' : (equipo.estado_proceso || 'PENDIENTE');

                  return (
                    <TableRow 
                      key={equipo.id}
                      className={getRowClassName(estadoAlerta)}
                    >
                      {!readOnly && (
                        <TableCell>
                          <Checkbox
                            checked={selectedIds.includes(equipo.id)}
                            onCheckedChange={() => handleToggleOne(equipo.id)}
                            disabled={!!equipo.fecha_salida}
                          />
                        </TableCell>
                      )}
                      <TableCell className="font-mono font-semibold text-gray-900 dark:text-gray-100">
                        {equipo.codigo_equipo}
                      </TableCell>
                      <TableCell className="truncate max-w-[150px]" title={equipo.cliente}>
                        {equipo.cliente}
                      </TableCell>
                      <TableCell className="text-center">
                        {equipo.marca_modelo && equipo.marca_modelo.trim() !== '' ? (
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => setObservacionesDialog({ open: true, content: equipo.marca_modelo || '' })}
                            className="h-8 w-8 p-0 hover:bg-blue-50 hover:text-blue-600"
                            title="Ver observaciones"
                          >
                            <Eye className="h-4 w-4" />
                          </Button>
                        ) : (
                          <span className="text-xs text-muted-foreground">-</span>
                        )}
                      </TableCell>
                      <TableCell className="text-sm">{equipo.motivo}</TableCell>
                      <TableCell className="text-sm">{equipo.area}</TableCell>
                      
                      {/* Días en custodia con tamaño reducido */}
                      <TableCell className="text-center">
                        <span className={`inline-flex items-center justify-center min-w-[1.75rem] h-6 px-2 rounded-full font-semibold text-xs ${
                          diasCustodia === 0 
                            ? 'bg-gray-100 text-gray-500' 
                            : diasCustodia > 3 && !equipo.fecha_salida
                            ? 'bg-orange-500 text-white'
                            : 'bg-blue-100 text-blue-700'
                        }`}>
                          {diasCustodia}
                        </span>
                      </TableCell>

                      <TableCell className="text-center">
                        {getEstadoBadge(estadoAlerta)}
                      </TableCell>
                      <TableCell className="text-sm text-gray-500">{formatFecha(equipo.fecha_ingreso)}</TableCell>
                      <TableCell className="text-sm text-gray-500">{formatFecha(equipo.fecha_salida, true)}</TableCell>
                      {!readOnly && (
                        <TableCell className="text-right">
                          <div className="flex items-center justify-end gap-2">
                            {!equipo.fecha_salida ? (
                              <Button
                                size="sm"
                                variant="outline"
                                onClick={() => onMarkExit(equipo)}
                                className="bg-emerald-50 hover:bg-emerald-100 border-emerald-200 text-emerald-700 h-8 w-8 p-0"
                                title="Marcar Salida"
                              >
                                <PackageCheck className="h-4 w-4" />
                              </Button>
                            ) : (
                              <div className="h-8 w-8 flex items-center justify-center">
                                <CheckCircle2 className="h-5 w-5 text-emerald-500" />
                              </div>
                            )}
                            {!equipo.fecha_salida ? (
                              <Button
                                size="sm"
                                variant="outline"
                                onClick={() => onEdit(equipo)}
                                title="Editar registro"
                                className="h-8 w-8 p-0"
                              >
                                <Pencil className="h-4 w-4" />
                              </Button>
                            ) : (
                              <Button
                                size="sm"
                                variant="outline"
                                disabled
                                className="opacity-50 cursor-not-allowed h-8 w-8 p-0"
                              >
                                <Pencil className="h-4 w-4" />
                              </Button>
                            )}
                          </div>
                        </TableCell>
                      )}
                    </TableRow>
                  );
                })
              )}
            </TableBody>
          </Table>
        </div>
      </div>

      {/* Vista móvil - Tarjetas */}
      <div className="lg:hidden space-y-3">
        {paginatedEquipos.length === 0 ? (
          <div className="text-center py-8 text-muted-foreground bg-white dark:bg-gray-950 border rounded-lg">
            {searchQuery || motivoFilter !== 'todos'
              ? 'No se encontraron equipos con los filtros seleccionados'
              : 'No hay equipos registrados.'}
          </div>
        ) : (
          paginatedEquipos.map((equipo) => {
            const diasCustodia = calcularDiasCustodia(equipo.fecha_ingreso, equipo.fecha_salida, equipo.dias_en_custodia);
            const estadoAlerta = calcularEstadoAlerta(equipo.fecha_salida, equipo.prioridad_alta);
            const estadoProceso = equipo.fecha_salida ? 'TERMINADO' : (equipo.estado_proceso || 'PENDIENTE');
            
            return (
              <div 
                key={equipo.id}
                className={`border rounded-lg p-4 space-y-3 shadow-sm bg-white dark:bg-gray-950 ${getRowClassName(estadoAlerta)}`}
              >
                {/* Header */}
                <div className="flex items-start justify-between gap-3">
                  <div className="flex items-start gap-3 flex-1 min-w-0">
                    {!readOnly && (
                      <Checkbox
                        checked={selectedIds.includes(equipo.id)}
                        onCheckedChange={() => handleToggleOne(equipo.id)}
                        disabled={!!equipo.fecha_salida}
                        className="mt-1"
                      />
                    )}
                    <div className="flex-1 min-w-0">
                      <p className="font-mono font-bold text-sm break-all max-w-[180px] lg:max-w-none">{equipo.codigo_equipo}</p>
                      <p className="text-xs text-muted-foreground mt-1 truncate max-w-[200px]" title={equipo.cliente}>
                        {equipo.cliente}
                      </p>
                    </div>
                  </div>
                  {getEstadoBadge(estadoAlerta)}
                </div>

                {/* Detalles */}
                <div className="grid grid-cols-2 gap-3 text-xs bg-white/50 dark:bg-black/20 p-2 rounded-md">
                  <div className="min-w-0">
                    <p className="text-muted-foreground text-[10px] uppercase tracking-wider mb-0.5">Observaciones</p>
                    {equipo.marca_modelo && equipo.marca_modelo.trim() !== '' ? (
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => setObservacionesDialog({ open: true, content: equipo.marca_modelo || '' })}
                        className="h-6 px-2 text-xs hover:bg-blue-50 hover:text-blue-600"
                      >
                        <Eye className="h-3 w-3 mr-1" />
                        Ver
                      </Button>
                    ) : (
                      <p className="text-xs text-muted-foreground">-</p>
                    )}
                  </div>
                  <div>
                    <p className="text-muted-foreground text-[10px] uppercase tracking-wider mb-0.5">Días en Custodia</p>
                    <span className={`inline-block px-1.5 py-0.5 rounded text-[10px] font-bold ${
                      diasCustodia > 3 && !equipo.fecha_salida
                        ? 'bg-red-100 text-red-700' 
                        : 'bg-gray-100 text-gray-700'
                    }`}>
                      {diasCustodia} DÍAS
                    </span>
                  </div>
                  <div>
                    <p className="text-muted-foreground text-[10px] uppercase tracking-wider mb-0.5">Motivo</p>
                    <p className="font-medium truncate">{equipo.motivo}</p>
                  </div>
                  <div className="col-span-2">
                    <p className="text-muted-foreground text-[10px] uppercase tracking-wider mb-0.5">Especialista / Área</p>
                    <p className="font-medium truncate">{equipo.area}</p>
                  </div>
                </div>

                {/* Footer Fechas */}
                <div className="flex justify-between text-[10px] text-gray-500 pt-1 border-t border-dashed">
                    <span>Ingreso: {formatFecha(equipo.fecha_ingreso)}</span>
                    <span>Salida: {formatFecha(equipo.fecha_salida, true)}</span>
                </div>

                {/* Acciones */}
                {!readOnly && (
                  <div className="flex gap-2 pt-2 flex-col sm:flex-row">
                    {!equipo.fecha_salida && (
                      <Select 
                        value={estadoProceso} 
                        onValueChange={(val) => onUpdateStatus(equipo, val)}
                      >
                        <SelectTrigger className="flex-1 h-8 text-xs bg-white">
                          <div className="flex items-center">
                            {estadoProceso === 'PENDIENTE' && <Clock className="w-3 h-3 mr-2" />}
                            {estadoProceso === 'EN_PROCESO' && <Loader2 className="w-3 h-3 mr-2 animate-spin" />}
                            <SelectValue placeholder="Estado" />
                          </div>
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="PENDIENTE">PENDIENTE</SelectItem>
                          <SelectItem value="EN_PROCESO">EN PROCESO</SelectItem>
                        </SelectContent>
                      </Select>
                    )}

                    <div className="flex gap-2 flex-1">
                      {!equipo.fecha_salida && (
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => onMarkExit(equipo)}
                          className="flex-1 bg-emerald-50 hover:bg-emerald-100 border-emerald-200 text-emerald-700 text-xs h-8"
                        >
                          <PackageCheck className="h-3 w-3 mr-1" />
                          Salida
                        </Button>
                      )}
                      {!equipo.fecha_salida ? (
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => onEdit(equipo)}
                          className="flex-1 text-xs h-8"
                        >
                          <Pencil className="h-3 w-3 mr-1" />
                          Editar
                        </Button>
                      ) : (
                        <Button
                          size="sm"
                          variant="outline"
                          disabled
                          className="flex-1 text-xs opacity-50 cursor-not-allowed h-8"
                        >
                          <Pencil className="h-3 w-3 mr-1" />
                          Bloqueado
                        </Button>
                      )}
                    </div>
                  </div>
                )}
              </div>
            );
          })
        )}
      </div>

      {/* Paginación */}
      {totalPages > 1 && (
        <div className="flex justify-center py-4">
          <Pagination>
            <PaginationContent>
              <PaginationItem>
                <PaginationPrevious 
                  onClick={() => setCurrentPage(prev => Math.max(1, prev - 1))}
                  className={currentPage === 1 ? 'pointer-events-none opacity-50' : 'cursor-pointer'}
                />
              </PaginationItem>
              
              {getPageNumbers().map((page, idx) => (
                <PaginationItem key={idx}>
                  {page === 'ellipsis' ? (
                    <PaginationEllipsis />
                  ) : (
                    <PaginationLink
                      onClick={() => setCurrentPage(page as number)}
                      isActive={currentPage === page}
                      className="cursor-pointer"
                    >
                      {page}
                    </PaginationLink>
                  )}
                </PaginationItem>
              ))}
              
              <PaginationItem>
                <PaginationNext 
                  onClick={() => setCurrentPage(prev => Math.min(totalPages, prev + 1))}
                  className={currentPage === totalPages ? 'pointer-events-none opacity-50' : 'cursor-pointer'}
                />
              </PaginationItem>
            </PaginationContent>
          </Pagination>
        </div>
      )}

      {/* Dialog para mostrar observaciones */}
      <Dialog open={observacionesDialog.open} onOpenChange={(open) => setObservacionesDialog({ ...observacionesDialog, open })}>
        <DialogContent className="sm:max-w-[500px]">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Eye className="h-5 w-5 text-blue-600" />
              Observaciones
            </DialogTitle>
            <DialogDescription>
              Detalles adicionales del equipo
            </DialogDescription>
          </DialogHeader>
          <div className="py-4">
            <p className="text-sm whitespace-pre-wrap">{observacionesDialog.content || 'Sin observaciones'}</p>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}