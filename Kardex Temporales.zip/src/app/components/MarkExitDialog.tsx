import { useState, useEffect } from 'react';
import { Copy, Check, Package } from 'lucide-react';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from './ui/dialog';
import { Button } from './ui/button';
import { Label } from './ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Textarea } from './ui/textarea';
import { toast } from 'sonner';

interface Equipment {
  id: number;
  codigo_equipo: string;
  cliente?: string;
  marca_modelo?: string;
}

interface MarkExitDialogProps {
  open: boolean;
  onClose: () => void;
  onSubmit: (data: any) => void;
  equipment: Equipment | null;
}

const ENTREGADO_A = ['Almacén', 'Almacén - Reparaciones', 'Logistica', 'Reparaciones', 'Cliente'];

export function MarkExitDialog({ open, onClose, onSubmit, equipment }: MarkExitDialogProps) {
  const [entregadoA, setEntregadoA] = useState('Almacén');
  const [estado, setEstado] = useState('Reservado ✅');
  const [observaciones, setObservaciones] = useState('');
  const [emailText, setEmailText] = useState('');
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    if (open && equipment) {
      setEntregadoA('Almacén');
      setEstado('Reservado ✅');
      setObservaciones('');
      setCopied(false);
      generateEmail();
    }
  }, [open, equipment]);

  // Efecto para cambiar automáticamente "Entregado A" cuando el estado es "Dañado"
  useEffect(() => {
    if (estado === 'Dañado ❌') {
      setEntregadoA('Almacén - Reparaciones');
    } else if (estado === 'Reservado ✅') {
      setEntregadoA('Almacén');
    }
  }, [estado]);

  useEffect(() => {
    generateEmail();
  }, [entregadoA, estado, equipment]);

  const generateEmail = () => {
    if (!equipment) return;

    const cliente = equipment.cliente || 'Sin cliente asignado';
    const emailBody = `Buenas tardes,

Cambiar el estado de los siguientes equipos temporales:

${equipment.codigo_equipo} // ${cliente} / ${estado} - ${entregadoA}

Saludos.`;
    
    setEmailText(emailBody);
  };

  const handleCopyEmail = () => {
    if (!emailText) {
      toast.error('No hay texto para copiar');
      return;
    }

    // Método de textarea que funciona en todos los navegadores
    const textArea = document.createElement('textarea');
    textArea.value = emailText;
    textArea.style.position = 'fixed';
    textArea.style.left = '-999999px';
    textArea.style.top = '-999999px';
    document.body.appendChild(textArea);
    textArea.focus();
    textArea.select();
    
    try {
      const successful = document.execCommand('copy');
      if (successful) {
        setCopied(true);
        toast.success('Correo copiado al portapapeles');
        setTimeout(() => setCopied(false), 2000);
      } else {
        toast.error('No se pudo copiar. Intenta seleccionar y copiar manualmente el texto.');
      }
    } catch (err) {
      console.error('Error al copiar:', err);
      toast.error('Error al copiar. Selecciona y copia manualmente el texto.');
    } finally {
      document.body.removeChild(textArea);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (!equipment) return;

    const data = {
      marcar_salida: true,
      entregado_a: entregadoA,
      observaciones_salida: observaciones || null
    };

    onSubmit(data);
  };

  if (!equipment) return null;

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-lg lg:text-xl">
            <Package className="h-4 w-4 lg:h-5 lg:w-5 text-green-600" />
            Marcar Salida del Equipo
          </DialogTitle>
          <DialogDescription className="text-sm">
            Registra la salida del equipo <strong className="text-foreground break-all">{equipment.codigo_equipo}</strong>
          </DialogDescription>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-4 lg:space-y-6">
          
          {/* Información del Equipo */}
          <div className="bg-gray-50 dark:bg-gray-900 rounded-lg p-3 lg:p-4 space-y-2">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 lg:gap-4">
              <div>
                <p className="text-xs lg:text-sm text-muted-foreground">Código</p>
                <p className="font-mono font-semibold text-sm lg:text-base break-all">{equipment.codigo_equipo}</p>
              </div>
              {equipment.marca_modelo && (
                <div>
                  <p className="text-xs lg:text-sm text-muted-foreground">Observaciones</p>
                  <p className="font-semibold text-sm lg:text-base">{equipment.marca_modelo}</p>
                </div>
              )}
              {equipment.cliente && (
                <div className="sm:col-span-2">
                  <p className="text-xs lg:text-sm text-muted-foreground">Cliente</p>
                  <p className="font-semibold text-sm lg:text-base">{equipment.cliente}</p>
                </div>
              )}
            </div>
          </div>

          {/* Entregado A - Automático según estado */}
          <div className="space-y-2">
            <Label htmlFor="entregado_a" className="text-sm lg:text-base">Entregado A <span className="text-red-500">*</span></Label>
            <div className="flex h-10 w-full items-center rounded-md border border-input bg-muted px-3 py-2 text-sm text-muted-foreground">
              {entregadoA}
            </div>
            <p className="text-xs text-muted-foreground">
              {estado === 'Reservado ✅' ? '✅ Automático: Almacén' : '⚠️ Automático: Almacén - Reparaciones'}
            </p>
          </div>

          {/* Estado */}
          <div className="space-y-2">
            <Label htmlFor="estado" className="text-sm lg:text-base">Estado para el Correo</Label>
            <Select value={estado} onValueChange={setEstado}>
              <SelectTrigger className="text-sm lg:text-base">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="Reservado ✅">Reservado ✅</SelectItem>
                <SelectItem value="Dañado ❌">Dañado ❌</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Observaciones */}
          <div className="space-y-2">
            <Label htmlFor="observaciones_salida" className="text-sm lg:text-base">Observaciones de Salida</Label>
            <Textarea
              id="observaciones_salida"
              value={observaciones}
              onChange={(e) => setObservaciones(e.target.value)}
              placeholder="Notas adicionales sobre la salida del equipo..."
              rows={3}
              className="text-sm"
            />
          </div>

          {/* Formato de Correo */}
          <div className="space-y-3 p-3 lg:p-4 bg-blue-50 dark:bg-blue-950/20 rounded-lg border border-blue-200 dark:border-blue-900">
            <div className="flex items-center justify-between gap-2">
              <Label className="text-sm lg:text-base font-semibold">📧 Formato de Correo</Label>
              <Button
                type="button"
                size="sm"
                variant="outline"
                onClick={handleCopyEmail}
                className="text-xs lg:text-sm"
              >
                {copied ? (
                  <>
                    <Check className="h-3 w-3 lg:h-4 lg:w-4 mr-1 lg:mr-2" />
                    Copiado
                  </>
                ) : (
                  <>
                    <Copy className="h-3 w-3 lg:h-4 lg:w-4 mr-1 lg:mr-2" />
                    Copiar
                  </>
                )}
              </Button>
            </div>
            <pre className="text-xs lg:text-sm p-2 lg:p-3 bg-white dark:bg-gray-800 rounded border whitespace-pre-wrap font-mono max-h-48 overflow-y-auto">
{emailText}
            </pre>
            <p className="text-xs text-muted-foreground">
              💡 Copia este texto y pégalo en tu cliente de correo
            </p>
          </div>

          {/* Botones */}
          <div className="flex flex-col sm:flex-row justify-end gap-2 lg:gap-3 pt-2 lg:pt-4">
            <Button type="button" variant="outline" onClick={onClose} className="w-full sm:w-auto">
              Cancelar
            </Button>
            <Button type="submit" className="w-full sm:w-auto bg-green-600 hover:bg-green-700">
              Marcar Salida
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}