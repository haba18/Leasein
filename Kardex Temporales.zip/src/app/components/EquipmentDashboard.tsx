import { LaptopMinimal, AlertTriangle, Clock, TrendingUp } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';

interface DashboardStats {
  total_en_preparacion: number;
  total_urgentes: number;
  equipos_retrasados: number;
  promedio_dias: number;
}

interface EquipmentDashboardProps {
  stats: DashboardStats;
}

export function EquipmentDashboard({ stats }: EquipmentDashboardProps) {
  return (
    <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4 mb-6">
      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium">
            Total en Preparación
          </CardTitle>
          <LaptopMinimal className="h-4 w-4 text-muted-foreground" />
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold">{stats.total_en_preparacion}</div>
          <p className="text-xs text-muted-foreground">
            Equipos en custodia
          </p>
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium">
            Equipos Urgentes
          </CardTitle>
          <AlertTriangle className="h-4 w-4 text-red-500" />
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold text-red-600">{stats.total_urgentes}</div>
          <p className="text-xs text-muted-foreground">
            Prioridad alta activa
          </p>
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium">
            Equipos Retrasados
          </CardTitle>
          <Clock className="h-4 w-4 text-orange-500" />
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold text-orange-600">{stats.equipos_retrasados}</div>
          <p className="text-xs text-muted-foreground">
            Más de 3 días sin salida
          </p>
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium">
            Promedio de Días
          </CardTitle>
          <TrendingUp className="h-4 w-4 text-muted-foreground" />
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold">{Math.round(stats.promedio_dias)}</div>
          <p className="text-xs text-muted-foreground">
            Días en custodia
          </p>
        </CardContent>
      </Card>
    </div>
  );
}
